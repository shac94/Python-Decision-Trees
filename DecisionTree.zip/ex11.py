# shaharc1994
# 205801541
# shahar cohen


import itertools


class Node:
    """
    this class represent the node object , this object represent a binary tree
    while the node is a vertex for the tree
    """

    def __init__(self, data, positive_child=None, negative_child=None):
        """
        this method define initial parameters to the object
        :param data: object parameter
        :param positive_child:object parameter
        :param negative_child:object parameter
        """
        self.data = data
        self.positive_child = positive_child
        self.negative_child = negative_child


class Record:
    """
    this class represent a object that include illness name and symptoms
    """

    def __init__(self, illness, symptoms):
        """
        this method define initial parameters to the object
        :param illness: ""
        :param symptoms: ""
        """
        self.illness = illness
        self.symptoms = symptoms


def parse_data(filepath):
    """
    this function get a file path and return lst of Record objects from the
    file
    :param filepath:""
    :return:
    """
    with open(filepath) as data_file:
        records = []
        for line in data_file:
            words = line.strip().split()
            records.append(Record(words[0], words[1:]))
        return records


class Diagnoser:
    """
    this class contains the root where there will be a Node object
    representing a tree root
    """

    def __init__(self, root):
        """
        this method define initial parameters to the object
        :param root: ""
        """
        self.root = root

    def diagnose(self, symptoms):
        """
        this method receive a symptoms list and return which illness is suit
        to the symptoms by the binary tree
        :param symptoms:
        :return:
        """
        return self.diagnose_helper(symptoms, self.root)

    def diagnose_helper(self, symptoms, root_node):
        """
        this method is helper to the method diagnose in this method we use a
        recursion step to find the correct illness in the binary tree
        :param symptoms: ""
        :param root_node: ""
        :return:
        """

        # base

        if root_node.positive_child is None and root_node.negative_child \
                is None:
            return root_node.data

        # recursion

        for symptom in symptoms:
            if root_node.data == symptom:
                return self.diagnose_helper(symptoms,
                                            root_node.positive_child)
        # to check
        return self.diagnose_helper(symptoms, root_node.negative_child)

    def calculate_success_rate(self, records):
        """
        This method checks how many times the illness was found in the
         binary tree and returns the times it was found divided by the
         amount of the illness
        :param records:""
        :return:
        """
        return self.calculate_success_rate_helper(records)

    def calculate_success_rate_helper(self, records, count=0):
        """
        this method is helper to the method calculate_success_rate
         in this method we use count how many times the diagnose succeed to
         find the right illness
        :param records: ""
        :param count: ""
        :return:
        """
        if len(records) == 0:
            return 0.0
        for record in records:
            illness_by_record = record.illness
            symptoms_by_record = record.symptoms
            if self.diagnose(symptoms_by_record) == illness_by_record:
                count += 1
        return count / len(records)

    def all_illnesses(self):
        """
        this method run over all the leaf in the binary tree and return a
        list with the leaf data
        :return:
        """
        illnesses_dict = {}
        self.all_illnesses_helper(self.root, illnesses_dict)
        illnesses_lst = sorted(illnesses_dict, key=illnesses_dict.get,
                               reverse=True)
        return illnesses_lst

    def all_illnesses_helper(self, root_node, illnesses_dict):
        """
        this method is a helper method by recursion move and check if the
        tree vertex is a leaf if yes its take the data from him and add it
        to a dict
        :param root_node: :""
        :param illnesses_dict: ""
        :return:
        """

        # base
        if root_node.positive_child is None and root_node.negative_child is \
                None:
            update_dict_illnesses(root_node.data, illnesses_dict)

        # recursion
        if root_node.positive_child is not None:
            self.all_illnesses_helper(root_node.positive_child,
                                      illnesses_dict)
        if root_node.negative_child is not None:
            self.all_illnesses_helper(root_node.negative_child,
                                      illnesses_dict)

    def paths_to_illness(self, illness):
        """
        this method get a illness name and return the boolean "road" to go
        to that illness by a list
        :param illness: ""
        :return: ""
        """
        boolean_lst = []
        lst = []
        self.paths_to_illness_helper(illness, self.root, boolean_lst, lst)
        return boolean_lst

    def paths_to_illness_helper(self, illness, root_node, boolean_lst, lst):
        """
        this method is helper to paths to illness by recursion moves it add
         a boolean expression to the lst until it find the illness important
         to notice that in can return many path to one illness
        :param illness: ""
        :param root_node: ""
        :param boolean_lst: ""
        :param lst: ""
        :return:
        """

        # base
        if root_node.positive_child is None and root_node.negative_child is \
                None and root_node.data == illness:
            boolean_lst.append(lst)

        # recursion
        if root_node.positive_child is not None:
            lst.append(True)
            self.paths_to_illness_helper(illness, root_node.positive_child,
                                         boolean_lst, lst[:])
            lst.pop()

        if root_node.negative_child is not None:
            lst.append(False)
            self.paths_to_illness_helper(illness, root_node.negative_child,
                                         boolean_lst, lst[:])
            lst.pop()


def update_dict_illnesses(illness, illnesses_dict):
    """
     this function check in illnesses in a dict if yes she add 1 to is
     count if not she update new dict val to the dict
     :param illness: ""
     :param illnesses_dict: ""
     :return:
    """
    if illness is None:
        return
    if illness in illnesses_dict:
        illnesses_dict[illness] += 1
        return
    illnesses_dict.update({illness: 1})


def build_tree(records, symptoms):
    """
    this function get a list of records and symptoms and by using helper
    function return a Node object that represent a tree with leafs that
    represent to most suitable illness
    :param records: ""
    :param symptoms: ""
    :return:
    """
    if len(symptoms) == 0 and records == 0:
        return Node(None)
    if len(symptoms) == 0:
        common_illness_root = common_illness(records, {})
        return Node(common_illness_root)
    root_tree = build_tree_helper(symptoms, [], [], records)

    return root_tree


def build_tree_helper(symptoms, leaf_symptoms, leaf_un_symptoms, records,
                      index=0):
    """
    this function is helper to build tree its build a binary tree by recursion
    steps it build for every leaf a two special list one is a good symptoms
    list and the second is a bad symptoms list and by that list the function
    know which illness is the suitable for this leaf
    :param symptoms:
    :param leaf_symptoms: good list symptoms
    :param leaf_un_symptoms:bad list symptoms
    :param records: ""
    :param index: recursion step
    :return: root tree
    """

    # base
    if len(symptoms) == 0:
        return
    if index == len(symptoms) - 1:
        last_node = Node(symptoms[index])

        # positive
        leaf_symptoms.append(symptoms[index])
        positive_leaf_records = filter_record(records, leaf_symptoms[:],
                                              leaf_un_symptoms[:], [])
        positive_leaf_illness = common_illness(positive_leaf_records[:], {})
        last_node.positive_child = Node(positive_leaf_illness)

        # pop
        leaf_symptoms.pop()

        # negative
        leaf_un_symptoms.append(symptoms[index])
        negative_leaf_records = filter_record(records, leaf_symptoms[:],
                                              leaf_un_symptoms[:], [])
        negative_leaf_illness = common_illness(negative_leaf_records[:], {})
        last_node.negative_child = Node(negative_leaf_illness)

        return last_node

    leaf_symptoms.append(symptoms[index])
    node_positive = build_tree_helper(symptoms, leaf_symptoms[:],
                                      leaf_un_symptoms[:], records, index + 1)
    leaf_symptoms.pop()

    leaf_un_symptoms.append(symptoms[index])
    node_negative = build_tree_helper(symptoms, leaf_symptoms[:],
                                      leaf_un_symptoms[:], records, index + 1)
    leaf_un_symptoms.pop()
    return Node(symptoms[index], node_positive, node_negative)


def filter_record(records, leaf_symptoms, leaf_un_symptoms, possible_records):
    """
    this function receive the leaf wanted and unwanted symptoms and filter the
    records by the leaf symptoms and return the possible records for the leaf
    :param records:
    :param leaf_symptoms:wanted symptoms lst
    :param leaf_un_symptoms:un wanted symptoms lst
    :param possible_records:""
    :return:""
    """
    for record in records:
        possible_record_flag = True
        record_symptoms = record.symptoms

        for symptom in record_symptoms:
            if symptom in leaf_un_symptoms:
                possible_record_flag = False
                break
        for leaf_symptom in leaf_symptoms:
            if leaf_symptom not in record_symptoms:
                possible_record_flag = False
                break
        if possible_record_flag:
            possible_records.append(record)
    return possible_records


def common_illness(possible_records, illnesses_dict):
    """
    this function check from all the records what record illness is the
     most common and return the illness
    :param possible_records: ""
    :param illnesses_dict: empty dict
    :return: most common illness
    """
    if len(possible_records) is 0:
        return
    for record in possible_records:
        illness = record.illness
        if illness == '':
            return
        if illness in illnesses_dict:
            illnesses_dict[illness] += 1
            continue
        illnesses_dict.update({illness: 1})
    illnesses_lst = sorted(illnesses_dict, key=illnesses_dict.get,
                           reverse=True)
    if len(illnesses_lst) == 0:
        return
    return illnesses_lst[0]


def convert_to_lst(symptoms, depth):
    """
    this function use a special outside function that return a iterator
    it make the iterator to a list of list of symptoms for the optimal tree
    function
    :param symptoms: ""
    :param depth: sub_group
    :return:list of list symptoms
    """
    combinations_symptoms_lst = list(itertools.combinations(symptoms, depth))
    for tuple_index in range(len(combinations_symptoms_lst)):
        combinations_symptoms_lst[tuple_index] = \
            list(combinations_symptoms_lst[tuple_index])
    return combinations_symptoms_lst


def optimal_tree(records, symptoms, depth):
    """
    this function use the build tree function and the covert to lst function
     and the method named calculate_success_rate it return the the tree
     success rate by the depth is gets
    :param records: ""
    :param symptoms: ""
    :param depth: ""
    :return: Node tree root
    """
    combinations_symptoms_lst = convert_to_lst(symptoms, depth)
    first_combinations_symptoms_lst = combinations_symptoms_lst[0]
    winner_success_tree = build_tree(records, first_combinations_symptoms_lst)
    root = Diagnoser(winner_success_tree)
    best_success_tree = root.calculate_success_rate(records)
    for symptoms_lst in combinations_symptoms_lst:
        candidate_tree = build_tree(records, symptoms_lst)
        candidate_root = Diagnoser(candidate_tree)
        candidate_success = candidate_root.calculate_success_rate(records)
        if candidate_success > best_success_tree:
            best_success_tree = candidate_success
            winner_success_tree = candidate_tree
    return winner_success_tree
